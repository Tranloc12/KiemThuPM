﻿namespace _30_Loc_43_N2_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSo1_30_Loc = new System.Windows.Forms.TextBox();
            this.txtSo2_30_Loc = new System.Windows.Forms.TextBox();
            this.txtKetQua_30_Loc = new System.Windows.Forms.TextBox();
            this.btCong_30_Loc = new System.Windows.Forms.Button();
            this.btnTru_30_Loc = new System.Windows.Forms.Button();
            this.btnNhan_30_Loc = new System.Windows.Forms.Button();
            this.btnChia_30_Loc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(170, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 44);
            this.label2.TabIndex = 0;
            this.label2.Text = "Số 1 ";
            // 
            // label
            // 
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(170, 150);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(82, 44);
            this.label.TabIndex = 1;
            this.label.Text = "Số 2";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(170, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 44);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ket Qua ";
            // 
            // txtSo1_30_Loc
            // 
            this.txtSo1_30_Loc.Location = new System.Drawing.Point(293, 67);
            this.txtSo1_30_Loc.Multiline = true;
            this.txtSo1_30_Loc.Name = "txtSo1_30_Loc";
            this.txtSo1_30_Loc.Size = new System.Drawing.Size(315, 38);
            this.txtSo1_30_Loc.TabIndex = 3;
            // 
            // txtSo2_30_Loc
            // 
            this.txtSo2_30_Loc.Location = new System.Drawing.Point(293, 156);
            this.txtSo2_30_Loc.Multiline = true;
            this.txtSo2_30_Loc.Name = "txtSo2_30_Loc";
            this.txtSo2_30_Loc.Size = new System.Drawing.Size(315, 38);
            this.txtSo2_30_Loc.TabIndex = 4;
            // 
            // txtKetQua_30_Loc
            // 
            this.txtKetQua_30_Loc.Location = new System.Drawing.Point(293, 243);
            this.txtKetQua_30_Loc.Multiline = true;
            this.txtKetQua_30_Loc.Name = "txtKetQua_30_Loc";
            this.txtKetQua_30_Loc.Size = new System.Drawing.Size(315, 38);
            this.txtKetQua_30_Loc.TabIndex = 5;
            // 
            // btCong_30_Loc
            // 
            this.btCong_30_Loc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCong_30_Loc.Location = new System.Drawing.Point(176, 341);
            this.btCong_30_Loc.Name = "btCong_30_Loc";
            this.btCong_30_Loc.Size = new System.Drawing.Size(90, 43);
            this.btCong_30_Loc.TabIndex = 7;
            this.btCong_30_Loc.Text = "Cộng";
            this.btCong_30_Loc.UseVisualStyleBackColor = true;
            this.btCong_30_Loc.Click += new System.EventHandler(this.btCong_30_Loc_Click);
            // 
            // btnTru_30_Loc
            // 
            this.btnTru_30_Loc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTru_30_Loc.Location = new System.Drawing.Point(293, 341);
            this.btnTru_30_Loc.Name = "btnTru_30_Loc";
            this.btnTru_30_Loc.Size = new System.Drawing.Size(90, 43);
            this.btnTru_30_Loc.TabIndex = 8;
            this.btnTru_30_Loc.Text = "Trừ";
            this.btnTru_30_Loc.UseVisualStyleBackColor = true;
            this.btnTru_30_Loc.Click += new System.EventHandler(this.btnTru_30_Loc_Click);
            // 
            // btnNhan_30_Loc
            // 
            this.btnNhan_30_Loc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhan_30_Loc.Location = new System.Drawing.Point(411, 341);
            this.btnNhan_30_Loc.Name = "btnNhan_30_Loc";
            this.btnNhan_30_Loc.Size = new System.Drawing.Size(90, 43);
            this.btnNhan_30_Loc.TabIndex = 9;
            this.btnNhan_30_Loc.Text = "Nhân";
            this.btnNhan_30_Loc.UseVisualStyleBackColor = true;
            this.btnNhan_30_Loc.Click += new System.EventHandler(this.btnNhan_30_Loc_Click);
            // 
            // btnChia_30_Loc
            // 
            this.btnChia_30_Loc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChia_30_Loc.Location = new System.Drawing.Point(536, 341);
            this.btnChia_30_Loc.Name = "btnChia_30_Loc";
            this.btnChia_30_Loc.Size = new System.Drawing.Size(90, 43);
            this.btnChia_30_Loc.TabIndex = 10;
            this.btnChia_30_Loc.Text = "Chia";
            this.btnChia_30_Loc.UseVisualStyleBackColor = true;
            this.btnChia_30_Loc.Click += new System.EventHandler(this.btnChia_30_Loc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnChia_30_Loc);
            this.Controls.Add(this.btnNhan_30_Loc);
            this.Controls.Add(this.btnTru_30_Loc);
            this.Controls.Add(this.btCong_30_Loc);
            this.Controls.Add(this.txtKetQua_30_Loc);
            this.Controls.Add(this.txtSo2_30_Loc);
            this.Controls.Add(this.txtSo1_30_Loc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSo1_30_Loc;
        private System.Windows.Forms.TextBox txtSo2_30_Loc;
        private System.Windows.Forms.TextBox txtKetQua_30_Loc;
        private System.Windows.Forms.Button btCong_30_Loc;
        private System.Windows.Forms.Button btnTru_30_Loc;
        private System.Windows.Forms.Button btnNhan_30_Loc;
        private System.Windows.Forms.Button btnChia_30_Loc;
    }
}

