﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using _30_Loc_43_N2_; // Namespace chứa lớp Caculation_30_Loc.


namespace UnitTest_30_Loc
{
    [TestClass] // Đánh dấu lớp này chứa các phương thức test.
    public class UnitTest1
    {
        private Caculation_30_Loc c_30_Loc; // Khai báo biến private của lớp Caculation_30_Loc.

        [TestInitialize] // Phương thức này sẽ chạy trước mỗi test case để thiết lập dữ liệu chung.
        public void SetUp_30_Loc()
        {
            c_30_Loc = new Caculation_30_Loc(10, 5); // Tạo một đối tượng Caculation_30_Loc với giá trị đầu vào (10, 5).
        }

        [TestMethod] // Đánh dấu phương thức này là một test method.
        // Test case 1: a = 10, b = 5, kết quả  = 15.
        public void TC1_Cong_30_Loc()
        {
            int expected_30_Loc, actual_30_Loc;
            expected_30_Loc = 15; // Đặt kết quả mong đợi cho phép cộng.
            actual_30_Loc = c_30_Loc.Execute("+"); // Thực thi phép cộng bằng toán tử "+".

            Assert.AreEqual(expected_30_Loc, actual_30_Loc); // Kiểm tra xem kết quả mong đợi có khớp với kết quả thực tế từ phương thức Execute không.
        }

        [TestMethod] // Đánh dấu phương thức này là một test method.
        public void TC2_Tru_30_Loc()
        {
            int expected_30_Loc, actual_30_Loc;
            expected_30_Loc = 5; // Đặt kết quả mong đợi cho phép trừ
            actual_30_Loc = c_30_Loc.Execute("-"); // Thực thi phép trừ bằng toán tử "-".

            Assert.AreEqual(expected_30_Loc, actual_30_Loc); // Kiểm tra xem kết quả mong đợi có khớp với kết quả thực tế từ phương thức Execute không.
        }

        [TestMethod] // Đánh dấu phương thức này là một test method.
        public void TC3_Nhan_30_Loc()
        {
            int expected_30_Loc, actual_30_Loc;
            expected_30_Loc = 50; // Đặt kết quả mong đợi cho phép nhân
            actual_30_Loc = c_30_Loc.Execute("*"); // Thực thi phép nhân bằng toán tử "*".

            Assert.AreEqual(expected_30_Loc, actual_30_Loc); // Kiểm tra xem kết quả mong đợi có khớp với kết quả thực tế từ phương thức Execute không.
        }

        [TestMethod] // Đánh dấu phương thức này là một test method.
        public void TC4_Chia_30_Loc()
        {
            int expected_30_Loc, actual_30_Loc;
            expected_30_Loc = 2; // Đặt kết quả mong đợi cho phép chia
            actual_30_Loc = c_30_Loc.Execute("/"); // Thực thi phép cộng bằng toán tử "/".

            Assert.AreEqual(expected_30_Loc, actual_30_Loc); // Kiểm tra xem kết quả mong đợi có khớp với kết quả thực tế từ phương thức Execute không.
        }

        [TestMethod] // Đánh dấu phương thức này là một test method.
        public void TC5_Cong_Fail_30_Loc()
        {
            int expected_30_Loc, actual_30_Loc;
            expected_30_Loc = 12; // Đặt kết quả mong đợi cho phép cộng.
            actual_30_Loc = c_30_Loc.Execute("+"); // Thực thi phép cộng bằng toán tử "+".

            Assert.AreEqual(expected_30_Loc, actual_30_Loc); // Kiểm tra xem kết quả mong đợi có khớp với kết quả thực tế từ phương thức Execute không.
        }

        [TestMethod] // Đánh dấu phương thức này là một test method.
        public void TC6_Tru_Fail_30_Loc()
        {
            int expected_30_Loc, actual_30_Loc;
            expected_30_Loc = 10; // Đặt kết quả mong đợi cho phép trừ
            actual_30_Loc = c_30_Loc.Execute("-"); // Thực thi phép trừ bằng toán tử "-".

            Assert.AreEqual(expected_30_Loc, actual_30_Loc); // Kiểm tra xem kết quả mong đợi có khớp với kết quả thực tế từ phương thức Execute không.
        }

        [TestMethod] // Đánh dấu phương thức này là một test method.
        public void TC7_Nhan_Fail_30_Loc()
        {
            int expected_30_Loc, actual_30_Loc;
            expected_30_Loc = 3; // Đặt kết quả mong đợi cho phép nhân
            actual_30_Loc = c_30_Loc.Execute("*"); // Thực thi phép nhân bằng toán tử "*".

            Assert.AreEqual(expected_30_Loc, actual_30_Loc); // Kiểm tra xem kết quả mong đợi có khớp với kết quả thực tế từ phương thức Execute không.
        }

        [TestMethod] // Đánh dấu phương thức này là một test method.
        public void TC8_Chia_Fial_30_Loc()
        {
            int expected_30_Loc, actual_30_Loc;
            expected_30_Loc = 4; // Đặt kết quả mong đợi cho phép chia
            actual_30_Loc = c_30_Loc.Execute("/"); // Thực thi phép cộng bằng toán tử "/".

            Assert.AreEqual(expected_30_Loc, actual_30_Loc); // Kiểm tra xem kết quả mong đợi có khớp với kết quả thực tế từ phương thức Execute không.
        }


        // Kiểm tra trường hợp chia cho 0 (xử lý ngoại lệ).
        [ExpectedException(typeof(DivideByZeroException))] // 
        public void Test_ChiaZero()
        {
            c_30_Loc = new Caculation_30_Loc(10, 0);
            c_30_Loc.Execute("/");
        }
    }
}
